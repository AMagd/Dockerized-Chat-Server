#!/usr/bin/env bash

python -u ./simple_chat/server.py